package org.example.spotify_music;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotifyMusicApplicationTests {

    @Test
    void contextLoads() {
    }

}
